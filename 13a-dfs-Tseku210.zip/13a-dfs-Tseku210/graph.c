#include "DS.h"
/*
	Графыг эхлүүлэх функц: `g` графын хөршүүдийг хадгалах жагсаалтан хүснэгтийг эхлүүлэх функц.
	Санах ойг бэлдэж, жагсаалтын `head`, `tail` утгуудад `NULL` онооно.
 */
void gr_init_graph(Graph *g, int n)
{
	int i;
	g->adj = (List *)malloc(sizeof(List) * (n + 1));
	g->n = n;
	for (i = 0; i <= n; i++)
	{
		g->adj[i].head = g->adj[i].tail = NULL;
		g->adj[i].len = 0;
	}
}
// Бүрдэл болгоны оройг тоолох
int pCnt = 1;

// DFS хэрэгжүүлэлт
void dfs(List *list, int *visited, int p)
{
	visited[p] = 1;
	Elm *start = list[p].head;
	while (start != NULL)
	{
		if (visited[start->x] == 0)
		{
			pCnt++;
			dfs(list, visited, start->x);
		}
		start = start->next;
	}
}

/*
	Гүний нэвтрэлтийн функц: `g` граф дээр гүний нэвтрэлт хийн холбоост бүрдлүүдийн талаарх
	даалгаварт заагдсан мэдээллийг хэвлэнэ.
 */
void gr_connected_components(Graph *g, int *cc)
{
	int i, cnt = 0;
	// Visited-ээ эхлээд очоогүйгээр (0) дүүргэнэ
	int visited[g->n];
	for (i = 0; i < g->n; i++)
	{
		visited[i] = 0;
	}
	for (i = 0; i < g->n; i++)
	{
		if (visited[i] == 0)
		{
			dfs(g->adj, visited, i);
			cc[cnt + 1] = pCnt;
			pCnt = 1;
			cnt++;
		}
	}
	cc[0] = cnt;
}

/*
	Ирмэг нэмэх функц: `g` графын ирмэгүүдийг хадгалах `adj` жагсаалтан хүснэгтэд ирмэг нэмнэ.
	Уг граф нь чиглэлгүй граф тул `x`-с `y`, `y`-с `x` гэсэн хоёр ирмэгийг оруулна.
 */
void gr_add_edge(Graph *g, int x, int y)
{
	// Тэгш хэмээр list-д оруулна
	l_push_back(&g->adj[x - 1], y - 1);
	l_push_back(&g->adj[y - 1], x - 1);
}
