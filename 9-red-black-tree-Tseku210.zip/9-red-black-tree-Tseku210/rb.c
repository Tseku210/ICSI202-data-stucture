#include "DS.h"

/*
  Хоёр оюутны мэдээллийн хооронд нь харьцуулах функц
*/
int less(const Student *a, const Student *b)
{
        if (strcmp(a->id, b->id) < 0)
                return 1;
        if (strcmp(a->id, b->id) == 0)
                return -1;
        return 0;
}

int isRed(Elm *el)
{
        if (el == NULL)
                return 0;
        return el->color == 0 ? 0 : 1;
}

Elm *rotate_left(Elm *root)
{
        Elm *el = root->R;
        root->R = el->L;
        el->L = root;
        el->color = root->color;
        root->color = 1;
        return el;
}

Elm *rotate_right(Elm *root)
{
        Elm *el = root->L;
        root->L = el->R;
        el->R = root;
        el->color = root->color;
        root->color = 1;
        return el;
}

void flip_colors(Elm *root)
{
        if (isRed(root))
                return;
        if (!isRed(root->L))
                return;
        if (!isRed(root->R))
                return;
        root->color = 1;
        root->L->color = 0;
        root->R->color = 0;
}

Elm *newEl(const Student *px)
{
        Elm *el = malloc(sizeof(Elm));
        el->x = *px;
        el->color = 1;
        el->L = NULL;
        el->R = NULL;
        return el;
}

Elm *insert(Elm *root, const Student *px)
{
        if (root == NULL)
                return newEl(px);

        if (less(&root->x, px) == 1) // left
                root->L = insert(root->L, px);
        else if (less(&root->x, px) == 0) // right
                root->R = insert(root->R, px);
        else
                root->x = *px;

        // if (isRed(root->R) && !isRed(root->L))
        //         root = rotate_left(root);
        // if (isRed(root->L) && isRed(root->L->L))
        //         root = rotate_right(root);
        // if (isRed(root->R) && isRed(root->L))
        //         flip_colors(root);

        return root;
}
/*
  `ptree`-ийн зааж байгаа модонд `x` утгыг оруулна.
  Мод хоосон байсан бол `ptree->root` хаяг өөрчлөгдөж шинээр орсон оройг заана.
  Хэрэв мод тэнцвэрээ алдсан бол тохирох тэнцвэржүүлэх үйлдлүүдийг хийнэ.
 */

void rb_put(RBT *ptree, const Student *px)
{
        ptree->root = insert(ptree->root, px);
}

/*
  `ptree`-ийн зааж байгаа модноос `x` утгыг хайн олдсон оройн `Elm*` хаягийг буцаана.
  Олдохгүй бол `NULL` хаягийг буцаана.
  Мод дандаа ялгаатай элементүүд хадгална гэж үзэж болно.
 */
Elm *rb_get(const RBT *ptree, const char id[])
{
        Elm *tmp = ptree->root;
        while (tmp != NULL)
        {
                if (strcmp(tmp->x.id, id) < 0)
                {
                        tmp = tmp->L;
                }
                else if (strcmp(tmp->x.id, id) > 0)
                {
                        tmp = tmp->R;
                }
                else if (strcmp(tmp->x.id, id) == 0)
                {
                        return tmp;
                }
        }
        return NULL;
}

/*
  Устгах функц: ТМноос `x` утгыг хайж олоод устгана.
  Олдохгүй бол юу ч хийхгүй.
  Хэрэв мод тэнцвэрээ алдсан бол тохирох тэнцвэржүүлэх үйлдлүүдийг хийнэ.
 */

Elm *rightMinValue(Elm *root)
{
        Elm *tmp = root;
        while (tmp && tmp->L != NULL)
        {
                tmp = tmp->L;
        }
        return tmp;
}

Elm *del(Elm *root, const char id[])
{
        Elm *tmp;
        if (root == NULL)
                return NULL;
        // Зүүн
        if (strcmp(root->x.id, id) < 0)
        {
                root->L = del(root->L, id);
        }
        else if (strcmp(root->x.id, id) > 0) // Баруун
        {
                root->R = del(root->R, id);
        }
        else
        {
                if (root->L == NULL && root->R == NULL)
                { // Навч байвал
                        free(root);
                        return NULL;
                }
                if (root->R == NULL)
                { // Ганц хүү байвал
                        tmp = root->L;
                        free(root);
                        return tmp;
                }
                else if (root->L == NULL)
                { // Ганц хүү байвал
                        tmp = root->R;
                        free(root);
                        return tmp;
                }
                else
                { // Хоёр хүү байвал
                        tmp = root->R;
                        while (tmp->L != NULL)
                                tmp = tmp->L;
                        root->x = tmp->x;
                        root->R = del(root->R, tmp->x.id);
                }
        }

        // if (isRed(root->R) && !isRed(root->L))
        //         root = rotate_left(root);
        // if (isRed(root->L) && isRed(root->L->L))
        //         root = rotate_right(root);
        // if (isRed(root->R) && isRed(root->L))
        //         flip_colors(root);

        return root;
}

void rb_del(RBT *ptree, const char id[])
{
        ptree->root = del(ptree->root, id);
}

void print(Elm *p)
{
        if (p)
                printf("%s %s %d %.1f\n", p->x.name, p->x.id, p->x.age, p->x.gpa);
        else
                printf("None\n");
}
