#include "DS.h"
#include <math.h>

/*
  p-ийн зааж буй CBTree-д x утгыг оруулна
*/
void cb_push(CBTree *p, int x)
{
        p->cb_arr[p->cb_len] = x;
        p->cb_len++;
}

/*
  p-ийн зааж буй CBTree-д idx индекстэй оройны зүүн хүүгийн индексийг буцаана.
  Зүүн хүү байхгүй бол -1 буцаана.
*/
int cb_left(const CBTree *p, int idx)
{
        int left_child = idx * 2 + 1;
        if (left_child < p->cb_len)
        {
                return left_child;
        }
        else
        {
                return -1;
        }
}

/*
  p-ийн зааж буй CBTree-д idx индекстэй оройны баруун хүүгийн индексийг буцаана.
  Баруун хүү байхгүй бол -1 буцаана.
*/
int cb_right(const CBTree *p, int idx)
{
        int right_child = idx * 2 + 1;
        if (right_child < p->cb_len)
        {
                return right_child + 1;
        }
        else
        {
                return -1;
        }
}

/*
  p-ийн зааж буй CBTree-с x тоог хайн
  хамгийн эхэнд олдсон индексийг буцаана.
  Олдохгүй бол -1 утгыг буцаана.
*/
int cb_search(const CBTree *p, int x)
{
        int i, len = p->tree.len;
        for (i = 0; i < len; i++)
        {
                if (p->tree.a[i] == x)
                {
                        return i;
                }
        }
        return -1;
}

/*
  p-ийн зааж буй CBTree-д idx индекстэй зангилаанаас дээшхи бүх өвөг эцэгийг олох үйлдлийг хийнэ.
  Тухайн орой өөрөө өвөг эцэгт орохгүй.
  Өвөг эцэг бүрийг нэг шинэ мөрөнд хэвлэнэ. Өвөг эцэгийг доороос дээшхи дарааллаар хэвлэнэ.
*/
void cb_ancestors(const CBTree *p, int idx)
{
        int i = idx;
        int ancestor_i;
        while (i > 0)
        {
                ancestor_i = floor((i - 1) / 2);
                printf("%d\n", p->cb_arr[ancestor_i]);
                i = ancestor_i;
        }
        // printf("%d\n", p->tree.a[0]);
}

/*
  p-ийн зааж буй CBTree-ийн өндрийг буцаана
*/
// int cb_height(const CBTree *p)
// {
//         int left_child_index = cb_left(p, 0);
//         int height = 1;
//         while (left_child_index != -1)
//         {
//                 left_child_index = cb_left(p, left_child_index);
//                 height++;
//         }
//         return height;
// }
int cb_height(const CBTree *p)
{
        int t = 0, x = p->cb_len - 1;
        if (x >= 0)
        {
                while (x > 0)
                {
                        t++;
                        x = (x - 1) / 2;
                }
                return t + 1;
        }
        else
        {
                return 0;
        }
}

/*
  p-ийн зааж буй CBTree-д idx оройны ах, дүү оройн дугаарыг буцаана.
  Тухайн оройн эцэгтэй адил эцэгтэй орой.
  Ах, дүү нь байхгүй бол -1-г буцаана.
*/
int cb_sibling(const CBTree *p, int idx)
{
        if (idx >= 0 && idx < p->cb_len)
        {
                int r = (idx - 1) % 2;
                if (r)
                {
                        return idx - 1;
                }
                else
                {
                        if ((idx + 1) < p->cb_len)
                                return idx + 1;
                        return -1;
                }
        }
        else
        {
                return -1;
        }
}

/*
  p-ийн зааж буй CBTree-г idx дугаартай зангилаанаас эхлэн preorder-оор хэвлэ.
  Орой бүрийг нэг шинэ мөрөнд хэвлэнэ.
*/
void cb_preorder(const CBTree *p, int idx)
{
        if (idx < p->cb_len)
        {
                printf("%d\n", p->cb_arr[idx]);
                cb_preorder(p, (2 * idx + 1));
                cb_preorder(p, (2 * idx + 2));
        }
        return;
}

/*
  p-ийн зааж буй CBTree-г idx дугаартай зангилаанаас эхлэн in-order-оор хэвлэ.
  Орой бүрийг нэг шинэ мөрөнд хэвлэнэ.
*/
void cb_inorder(const CBTree *p, int idx)
{
        if (idx < p->cb_len)
        {
                cb_inorder(p, (2 * idx + 1));
                printf("%d\n", p->cb_arr[idx]);
                cb_inorder(p, (2 * idx + 2));
        }
        return;
}

/*
  p-ийн зааж буй CBTree-г idx дугаартай зангилаанаас эхлэн post-order-оор хэвлэ.
  Орой бүрийг нэг шинэ мөрөнд хэвлэнэ.
 */
void cb_postorder(const CBTree *p, int idx)
{
        if (idx < p->cb_len)
        {
                cb_postorder(p, (2 * idx + 1));
                cb_postorder(p, (2 * idx + 2));
                printf("%d\n", p->cb_arr[idx]);
        }
        return;
}

/*
  p-ийн зааж буй CBTree-с idx дугаартай зангилаанаас доошхи бүх навчийг олно.
  Навч тус бүрийн утгыг шинэ мөрөнд хэвлэнэ.
  Навчыг зүүнээс баруун тийш олдох дарааллаар хэвлэнэ.
*/
int a = 0;
void cb_leaves(const CBTree *p, int idx)
{
        if (idx < p->cb_len)
        {
                cb_leaves(p, (2 * idx + 1));
                cb_leaves(p, (2 * idx + 2));
        }
        else if (a != (idx - 1) / 2)
        {
                a = (idx - 1) / 2;
                printf("%d\n", p->cb_arr[a]);
        }
        return;
}

/*
  p-ийн зааж буй CBTree-д idx индекстэй оройноос доошхи бүх үр садыг хэвлэнэ.
  Тухайн орой өөрөө үр сад болохгүй.
  Үр, сад бүрийг нэг шинэ мөрөнд хэвлэнэ. Үр садыг pre-order дарааллаар хэлэх ёстой.
*/
void cb_descendants(const CBTree *p, int idx)
{
        if (idx <= p->cb_len)
        {
                int left = idx * 2 + 1;
                int right = idx * 2 + 2;
                if (left < p->cb_len)
                {
                        printf("%d\n", p->cb_arr[left]);
                }
                if (left < p->cb_len)
                {
                        cb_descendants(p, left);
                }
                if (right < p->cb_len)
                {
                        printf("%d\n", p->cb_arr[right]);
                }
                if (right < p->cb_len)
                {
                        cb_descendants(p, right);
                }
        }
}

/*
  p-ийн зааж буй Tree-д хэдэн элемент байгааг буцаана.
  CBTree-д өөрчлөлт оруулахгүй.
*/
int cb_size(const CBTree *p)
{
        return p->cb_len;
}

/*
  p-ийн зааж буй CBTree-д x утгаас үндэс хүртэлх оройнуудын тоог буцаана.
  x тоо олдохгүй бол -1-г буцаана.
*/
int cb_level(const CBTree *p, int x)
{
        int i, j, s, rank;
        for (i = 0, s = 0; i < p->cb_len; i++)
        {
                if (x == p->cb_arr[i])
                {
                        s = 1;
                }
                if (s == 1)
                {
                        for (j = i, rank = 0; j > 0;)
                        {
                                j = (j - 1) / 2;
                                rank++;
                        }
                        return rank;
                }
        }
        return -1;
}
