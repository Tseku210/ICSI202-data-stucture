#include "DS.h"

/* p-ийн зааж буй List-д x утгыг төгсгөлд хийнэ */
void l_push_back(List *p, Student x)
{
  Elm *el = malloc(sizeof(struct Elm));
  el->x = x;
  el->next = NULL;
  if (p->len == 0)
  {
    p->tail = el;
    p->head = el;
    p->len++;
    return;
  }
  p->tail->next = el;
  p->tail = el;
  p->len++;
}

/* p-ийн зааж буй List-д x утгыг эхэнд хийнэ
   Бүх элементүүд нэг нэг байрлал хойшилно.
 */
void l_push_front(List *p, Student x)
{
  Elm *el = malloc(sizeof(struct Elm));
  el->x = x;
  el->next = NULL;
  if (p->head == NULL)
  {
    p->head = el;
    p->tail = el;
    p->len++;
    return;
  }
  el->next = p->head;
  p->head = el;
  p->len++;
}

/*
  p-ийн зааж буй List-д x утгыг pos байрлалд хийнэ
  pos болон түүнээс хойшхи элементүүд нэг байрлал ухарна.
  Тухайн байрлал List-ийн сүүлийн индексээс их бол төгсгөлд орно.
 */
void l_insert(List *p, Student x, int pos)
{
  if (pos >= p->len)
  {
    l_push_back(p, x);
    return;
  }
  if (pos == 0)
  {
    l_push_front(p, x);
    return;
  }
  Elm *el = malloc(sizeof(struct Elm));
  Elm *tmp = p->head;
  int i;
  for (i = 1; i < pos; i++)
  {
    tmp = tmp->next;
  }
  el->x = x;
  el->next = tmp->next; // 1 2 3 4 5
  tmp->next = el;
  p->len++;
}

/*
  p-ийн зааж буй List-н эхлэлээс гаргана.
  List-ийн бүх элементүүд нэг нэг байрлал урагшилна
 */
void l_pop_front(List *p)
{
  if (p->head == NULL)
    return;
  Elm *tmp = p->head;
  p->head = p->head->next;
  free(tmp);
  p->len--;
}

/* p-ийн зааж буй List-н төгсгөлөөс гаргана */
void l_pop_back(List *p)
{
  if (p->head == NULL) // 1 2 3 4 5
    return;
  if (p->len == 1)
  {
    l_pop_front(p);
    return;
  }
  int i;
  Elm *el = p->head;
  for (i = 2; i < p->len; i++) // 1 2 3 4 5
  {
    el = el->next;
  }
  // while (el->next != p->tail)
  // {
  //   el = el->next;
  // }
  free(p->tail);
  p->tail = el;
  p->tail->next = NULL;
  p->len--;
}

/* p-ийн зааж буй List-н pos байрлалаас гаргана.
   pos болон түүнээс хойшхи элементүүд нэг байрлал урагшилна.
   pos байрлалаас гарах боломжгүй бол юу ч хийхгүй.
 */
void l_erase(List *p, int pos)
{
  if (p->len == 0 || p->head == NULL || pos > p->len - 1)
    return;
  if (pos == 0 || p->len == 1)
  {
    l_pop_front(p);
    return;
  }
  if (pos == p->len - 1)
  {
    l_pop_back(p);
    return;
  }
  int i;
  Elm *prev, *tmp = p->head;
  for (i = 0; i < pos - 1; i++) // 1 2 3 4 5
  {
    tmp = tmp->next;
  }
  prev = tmp->next;
  tmp->next = prev->next;
  free(prev);
  p->len--;
}

/*
  p-ийн зааж буй List-н утгуудыг хэвлэнэ.
  Хамгийн эхний элементээс эхлэн дарааллаар, нэг мөрөнд
  нэг л элемент хэвлэнэ.
 */
void l_print(List *p)
{
  Elm *tmp = p->head;
  int len = p->len;
  while (len > 0)
  {
    printf("%s %s %s\n", tmp->x.id, tmp->x.ovog, tmp->x.ner);
    tmp = tmp->next;
    len--;
  }
}

/*
  p-ийн зааж буй List-с id-тай оюутныг хайн олдсон хаягийг буцаана.
  Олдохгүй бол NULL хаяг буцаана.
 */
Elm *l_search(List *p, const char id[])
{
  int i;
  Elm *el = p->head;
  if (el == NULL)
    return NULL;
  for (i = 0; i < p->len; i++)
  {
    if (strcmp(el->x.id, id) == 0)
    {
      return el;
    }
    el = el->next;
  }
  while (el != NULL)
  {
    if (strcmp(el->x.id, id) == 0)
      return el;

    el = el->next;
  }
  return NULL;
}
