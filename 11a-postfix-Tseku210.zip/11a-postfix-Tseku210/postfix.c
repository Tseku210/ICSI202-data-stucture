#include "DS.h"

int is_space(int x)
{
	switch (x)
	{
	case ' ':
	case '\t':
	case '\n':
	case '\r':
	case '\f':
	case '\v':
	case '\0':
		return 1;
	default:
		return 0;
	}
	return 0;
}

int convert_to_int(const char s[])
{
	int len = strlen(s);
	int t = 0, i;
	for (i = 0; i < len; i++)
		t = t * 10 + s[i] - '0';
	return t;
}

void tokenize(const char s[], List *p_list)
{
	char tmp[EQUATION_LENGTH];
	int i, j, k, len;
	j = 0;
	struct Token x;
	len = strlen(s);
	for (i = 0; i <= len; i++)
	{
		if ('0' <= s[i] && s[i] <= '9')
		{
			/* цифр орж ирлээ */
			tmp[j] = s[i];
			j++;
		}
		else
		{
			/* тэмдэгт орж ирлээ */
			if (j != 0)
			{ /* Хөрвүүлэх тоо байгаа эсэх */
				tmp[j] = '\0';
				j = 0;
				/* хадгалсан цифрийн цувааг int-рүү хөрвүүл */
				k = convert_to_int(tmp);
				x.flag = 1;
				x.val = k;
				/*
					Жагсаалтанд x элемнтийг оруулах
					Жагсаалтын push_back функцыг дуудна
				*/
				l_push_back(p_list, x);
			}
			/*
				тэмдэгтийг жагсаалтанд оруулах
				Жагсаалтын push_back функцыг дуудна
			 */
			if (is_space(s[i])) /* хоосон зай, шинэ мөрийг хаяна. */
				continue;

			/*
				Энд +, -, *, /, (, ) тэмдэгтүүдийг жагсаалтад оруулна.
			 */
			x.flag = 0;
			x.op = s[i];
			l_push_back(p_list, x);
		}
	}

	/* Тэмдэгтэн цуваанаас салгасан тэгшитгэлийг хэвлэх
		 Жагсаалтын print функцыг дуудна.
	 */
	// l_print(p_list);
}

int less(int a, char b)
{
	if (b == '+' || b == '-')
		return 0;
	if (b == '/' || b == '*' || b == '%')
	{
		if (a == '+' || a == '-')
			return 1;
		return 0;
	}
	return 0;
}
/*
	p_token - жагсаалтад байгаа тэгштгэлийг postfix-рүү хөрвүүлнэ
 */
void convert_to_postfix(List *p_token, List *p_post)
{
	// Stack
	Stack stack;
	stack.top = NULL;
	stack.len = 0;

	// Logic
	TokenElm *tmp = p_token->head;
	Elm *p;
	Token t;
	while (tmp != NULL)
	{
		if (tmp->x.flag == 1)
		{
			l_push_back(p_post, tmp->x);
		}
		else if (tmp->x.flag == 0)
		{
			if (tmp->x.op == '(')
			{
				s_push(&stack, tmp->x.op);
			}
			else if (tmp->x.op == ')')
			{
				p = stack.top;
				while (p->x != '(' && p != NULL)
				{
					t.flag = 0;
					t.op = p->x;
					l_push_back(p_post, t);
					s_pop(&stack);
					p = stack.top;
				}
				if (p->x == '(')
					s_pop(&stack);
			}
			else
			{
				if (stack.len == 0 || stack.top->x == '(' || less(stack.top->x, tmp->x.op))
				{
					s_push(&stack, tmp->x.op);
				}
				else
				{
					p = stack.top;
					while (p != NULL && p->x != '(' && !less(p->x, tmp->x.op))
					{
						t.flag = 0;
						t.op = p->x;
						l_push_back(p_post, t);
						s_pop(&stack);
						p = stack.top;
					}
					s_push(&stack, tmp->x.op);
				}
			}
		}
		tmp = tmp->next;
	}
	while (stack.top != NULL)
	{
		t.flag = 0;
		t.op = stack.top->x;
		l_push_back(p_post, t);
		stack.top = stack.top->next;
	}
}

int evaluate(int a, int b, char op)
{
	int res = b;
	if (op == '+')
		return res += a;
	if (op == '-')
		return res -= a;
	if (op == '*')
		return res *= a;
	if (op == '/')
		return res /= a;
	if (op == '%')
		return res %= a;
	return -1;
}

int solve(List *p_post)
{
	Stack stack;
	TokenElm *el = p_post->head;
	int a, b;
	while (el != NULL)
	{
		if (el->x.flag == 1)
		{
			s_push(&stack, el->x.val);
		}
		else
		{
			// Ehnii 2 element
			a = stack.top->x;
			s_pop(&stack);
			b = stack.top->x;
			s_pop(&stack);
			s_push(&stack, evaluate(a, b, el->x.op));
		}
		el = el->next;
	}
	return stack.top->x;
}
