#include "DS.h"
/*
  p-ийн зааж буй Stack-т x утгыг оруулна
 */
void s_push(Stack *p, int x)
{
        Elm *el = malloc(sizeof(Elm));
        el->x = x;
        if (p->top == NULL)
        {
                p->top = el;
                p->top->next = NULL;
                p->len++;
                return;
        }
        el->next = p->top;
        p->top = el;
        p->len++;
}
/*
  p-ийн зааж буй Stack-аас гарах функц
 */
void s_pop(Stack *p)
{
        if (p->len == 0)
                return;
        Elm *tmp = p->top;
        p->top = p->top->next;
        free(tmp);
        p->len--;
}
/*
    p-ийн зааж буй Stack-д байгаа элементүүдийг хэвлэх функц.
    Хамгийн сүүлд орсон элементээс эхлэн дарааллаар, нэг мөрөнд
    нэг л элемент хэвлэнэ.
 */
void s_print(Stack *p)
{
        Elm *tmp = p->top;
        while (tmp != NULL)
        {
                printf("%c\n", tmp->x);
                tmp = tmp->next;
        }
}
