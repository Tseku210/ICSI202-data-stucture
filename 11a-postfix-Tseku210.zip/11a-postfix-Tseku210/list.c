#include "DS.h"

/* p-ийн зааж буй List-д x утгыг төгсгөлд хийнэ */
void l_push_back(List *p, Token x)
{
  TokenElm *el = malloc(sizeof(struct TokenElm));
  el->x = x;
  el->next = NULL;
  if (p->len == 0)
  {
    p->tail = el;
    p->head = el;
    p->len++;
    return;
  }
  p->tail->next = el;
  p->tail = el;
  p->len++;
}

/* p-ийн зааж буй List-д x утгыг эхэнд хийнэ
   Бүх элементүүд нэг нэг байрлал хойшилно.
 */
void l_push_front(List *p, Token x)
{
  TokenElm *el = malloc(sizeof(struct TokenElm));
  el->x = x;
  el->next = NULL;
  if (p->head == NULL)
  {
    p->head = el;
    p->tail = el;
    p->len++;
    return;
  }
  el->next = p->head;
  p->head = el;
  p->len++;
}

/*
  p-ийн зааж буй List-д x утгыг pos байрлалд хийнэ
  pos болон түүнээс хойшхи элементүүд нэг байрлал ухарна.
  Тухайн байрлал List-ийн сүүлийн индексээс их бол төгсгөлд орно.
 */
void l_insert(List *p, Token x, int pos)
{
  if (pos >= p->len)
  {
    l_push_back(p, x);
    return;
  }
  if (pos == 0)
  {
    l_push_front(p, x);
    return;
  }
  TokenElm *el = malloc(sizeof(struct TokenElm));
  TokenElm *tmp = p->head;
  int i;
  for (i = 1; i < pos; i++)
  {
    tmp = tmp->next;
  }
  el->x = x;
  el->next = tmp->next; // 1 2 3 4 5
  tmp->next = el;
  p->len++;
}

/*
  p-ийн зааж буй List-н эхлэлээс гаргана.
  List-ийн бүх элементүүд нэг нэг байрлал урагшилна
 */
void l_pop_front(List *p)
{
  if (p->head == NULL)
    return;
  TokenElm *tmp = p->head;
  p->head = p->head->next;
  free(tmp);
  p->len--;
}

/* p-ийн зааж буй List-н төгсгөлөөс гаргана */
void l_pop_back(List *p)
{
  if (p->head == NULL) // 1 2 3 4 5
    return;
  if (p->len == 1)
  {
    l_pop_front(p);
    return;
  }
  int i;
  TokenElm *el = p->head;
  for (i = 2; i < p->len; i++) // 1 2 3 4 5
  {
    el = el->next;
  }
  free(p->tail);
  p->tail = el;
  p->tail->next = NULL;
  p->len--;
}

/* p-ийн зааж буй List-н pos байрлалаас гаргана.
   pos болон түүнээс хойшхи элементүүд нэг байрлал урагшилна.
   pos байрлалаас гарах боломжгүй бол юу ч хийхгүй.
 */
void l_erase(List *p, int pos)
{
  if (p->len == 0 || p->head == NULL || pos > p->len - 1)
    return;
  if (pos == 0 || p->len == 1)
  {
    l_pop_front(p);
    return;
  }
  if (pos == p->len - 1)
  {
    l_pop_back(p);
    return;
  }
  int i;
  TokenElm *prev, *tmp = p->head;
  for (i = 0; i < pos - 1; i++) // 1 2 3 4 5
  {
    tmp = tmp->next;
  }
  prev = tmp->next;
  tmp->next = prev->next;
  free(prev);
  p->len--;
}

/*
  p-ийн зааж буй List-н утгуудыг хэвлэнэ.
  Хамгийн эхний элементээс эхлэн дарааллаар, нэг мөрөнд
  нэг л элемент хэвлэнэ.
 */
void l_print(List *p)
{
  TokenElm *tmp = p->head;
  while (tmp != NULL)
  {
    if (tmp->x.flag)
    {
      printf("%d", tmp->x.val);
    }
    else
    {
      printf("%c", tmp->x.op);
    }
    tmp = tmp->next;
  }
}
