#include "my_qsort.h"

/*
  quicksort эрэмбэлэх аргын цааш хуваагдах ёсгүй хэмжээ
*/
#ifndef CUTOFF
#define CUTOFF 10
#endif

static int init_seed = 0; // Random seed 1 удаа эхлүүлнэ

/*
  Оруулан эрэмбэлэх функц.
  [lo, hi] завсрах тоонуудыг оруулан эрэмбэлэх аргаар эрэмбэлнэ.
*/
static void insertion_sort(int a[], int lo, int hi)
{
        int i, j, el;
        for (i = lo + 1; i <= hi; i++)
        {
                el = a[i];
                j = i - 1;
                while (j >= lo && el < a[j])
                {
                        a[j + 1] = a[j];
                        j--;
                }
                a[j + 1] = el;
        }
}

/*
  Хоёр утгыг хооронд солих функц
*/
static void swap(int *a, int *b)
{
        int tmp = *a;
        *a = *b;
        *b = tmp;
}

/*
  [lo, hi] завсрыг санамсаргүйгээр холих функц.
*/
static void random_shuffle(int a[], int lo, int hi)
{
        if (init_seed == 0)
        {
                srand(time(NULL));
                init_seed = 1;
        }
        int i, j;
        for (i = lo; i <= hi; i++)
        {
                j = rand() % (hi - lo) + lo;
                swap(&a[i], &a[j]);
        }
}

static void _random_partition(int a[], int lo, int hi)
{
        int pivotIndex = rand() % (hi - lo + 1) + lo;
        swap(&a[pivotIndex], &a[lo]);
}

static int _partition(int a[], int lo, int hi)
{
        if (lo >= hi)
                return hi;
        int pivot = lo;
        int i = lo, j = hi; // 9 9 22 11 25 6 31 43 37 37
        while (i < j)
        {
                while (a[i] <= a[pivot] && i < hi)
                {
                        i++;
                }
                while (a[j] > a[pivot])
                {
                        j--;
                }
                if (i < j)
                {
                        swap(&a[i], &a[j]);
                }
        }
        swap(&a[pivot], &a[j]);
        return j;
}

/*
  1-pivot хурдан эрэмбэлэх функц.
*/
static void _single_pivot_qsort(int a[], int lo, int hi)
{
        if (hi - lo <= CUTOFF)
        {
                insertion_sort(a, lo, hi);
                return;
        }
        if (hi <= lo)
                return;
        //_random_partition(a, lo, hi);
        int j = _partition(a, lo, hi);
        _single_pivot_qsort(a, lo, j - 1);
        _single_pivot_qsort(a, j + 1, hi);
}

/*
  wrapper function for _single_pivot_qsort
  _single_pivot_qsort-ыг дуудахад ашиглах функц
 */
void single_pivot_qsort(int a[], int lo, int hi)
{
        random_shuffle(a, lo, hi);
        _single_pivot_qsort(a, lo, hi);
}

static int _dual_partition(int a[], int lo, int hi, int *lp)
{
        if (a[lo] > a[hi])
        {
                swap(&a[lo], &a[hi]);
        }
        int j = lo + 1;
        int g = hi - 1, k = lo + 1, p = a[lo], q = a[hi];
        while (k <= g)
        {
                if (a[k] < p)
                {
                        swap(&a[k], &a[j]);
                        j++;
                }
                else if (a[k] >= q)
                {
                        while (a[g] > q && k < g)
                                g--;
                        swap(&a[k], &a[g]);
                        g--;
                        if (a[k] < p)
                        {
                                swap(&a[k], &a[j]);
                                j++;
                        }
                }
                k++;
        }
        j--;
        g++;
        swap(&a[lo], &a[j]);
        swap(&a[hi], &a[g]);

        *lp = j;
        return g;
}

/*
  Dual-pivot хурдан эрэмбэлэх функц
*/
static void _dual_pivot_qsort(int a[], int lo, int hi)
{
        if (hi - lo <= CUTOFF)
        {
                insertion_sort(a, lo, hi);
                return;
        }
        if (lo >= hi)
                return;
        int lp, rp;
        rp = _dual_partition(a, lo, hi, &lp);
        _dual_pivot_qsort(a, lo, lp - 1);
        _dual_pivot_qsort(a, lp + 1, rp - 1);
        _dual_pivot_qsort(a, rp + 1, hi);
}
/*
  wrapper function for _dual_pivot_qsort
  _dual_pivot_qsort-ыг дуудахад ашиглах функц
*/
void dual_pivot_qsort(int a[], int lo, int hi)
{
        random_shuffle(a, lo, hi);
        _dual_pivot_qsort(a, lo, hi);
}
