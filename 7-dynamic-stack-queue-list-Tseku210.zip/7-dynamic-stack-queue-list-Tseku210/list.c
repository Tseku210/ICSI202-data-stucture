#include "DS.h"

/* p-ийн зааж буй List-д x утгыг төгсгөлд хийнэ */
void l_push_back(List *p, int x)
{
  // printf("\nBackInserted %d %d", x, p->len);
  Elm *el = malloc(sizeof(struct Elm));
  el->x = x;
  el->next = NULL;
  if (p->len == 0)
  {
    p->head = el;
    p->tail = el;
    p->len++;
    return;
  }
  p->tail->next = el;
  p->tail = el;
  p->len++;
}

/* p-ийн зааж буй List-д x утгыг эхэнд хийнэ
   Бүх элементүүд нэг нэг байрлал хойшилно.
 */
void l_push_front(List *p, int x)
{
  // printf("\nFrontInserted %d", x);
  Elm *el = malloc(sizeof(struct Elm));
  el->x = x;
  el->next = NULL;
  if (p->len == 0)
  {
    p->head = el;
    p->tail = el;
    p->len++;
    return;
  }
  el->next = p->head;
  p->head = el;
  p->len++;
}

/*
  p-ийн зааж буй List-д x утгыг pos байрлалд хийнэ
  pos болон түүнээс хойшхи элементүүд нэг байрлал ухарна.
  Тухайн байрлал List-ийн сүүлийн индексээс их бол төгсгөлд орно.
 */
void l_insert(List *p, int x, int pos)
{
  if (pos >= p->len)
  {
    l_push_back(p, x);
    return;
  }
  else if (pos == 0)
  {
    l_push_front(p, x);
    return;
  }
  // printf("\nAInserted %d", x);
  Elm *el = malloc(sizeof(struct Elm));
  int i;
  Elm *tmp = p->head;
  Elm *prev;
  for (i = 0; i < pos; i++)
  { // 1 2 3 5 6 7
    if (i == pos - 1)
    {
      prev = tmp;
    }
    tmp = tmp->next;
  }
  el->x = x;
  el->next = tmp;
  prev->next = el;
  p->len++;
}

/*
  p-ийн зааж буй List-н эхлэлээс гаргана.
  List-ийн бүх элементүүд нэг нэг байрлал урагшилна
 */
void l_pop_front(List *p)
{
  if (p->len == 0)
    return;
  Elm *tmp = p->head;
  p->head = p->head->next;
  free(tmp);
  p->len--;
}

/* p-ийн зааж буй List-н төгсгөлөөс гаргана */
void l_pop_back(List *p)
{
  if (p->len == 0) // 1 2 3 4 5
    return;
  Elm *tmp = p->tail;
  p->tail = NULL;
  free(tmp);
  int i;
  Elm *el = p->head;
  for (i = 0; i < p->len; i++)
  {
    if (i == p->len - 2)
    {
      p->tail = el;
      break;
    }
    el = el->next;
  }
  p->len--;
}

/* p-ийн зааж буй List-н pos байрлалаас гаргана.
   pos болон түүнээс хойшхи элементүүд нэг байрлал урагшилна.
   pos байрлалаас гарах боломжгүй бол юу ч хийхгүй.
 */
void l_erase(List *p, int pos)
{
  if (p->len == 0 || pos >= p->len || pos < 0)
    return;
  if (pos == 0)
  {

    // printf("\nErased %d", p->head->x);
    l_pop_front(p);
    return;
  }
  if (pos == p->len - 1 || pos == p->len)
  {
    // printf("\nErased %d", p->tail->x);
    l_pop_back(p);
    return;
  }
  int i;
  Elm *tmp = p->head;
  Elm *prev;
  for (i = 0; i < pos; i++)
  { // 1 2 3 4 5 6 7
    if (i == pos - 1)
    {
      prev = tmp;
    }
    tmp = tmp->next;
  }
  prev->next = tmp->next;
  // printf("\nErased %d", tmp->x);
  free(tmp);
  p->len--;
}

/*
  p-ийн зааж буй List-н утгуудыг хэвлэнэ.
  Хамгийн эхний элементээс эхлэн дарааллаар, нэг мөрөнд
  нэг л элемент хэвлэнэ.
 */
void l_print(List *p)
{
  Elm *tmp = p->head; // 1 8 7 3 ->0
  int len = p->len;
  while (len > 0)
  {
    printf("%d\n", tmp->x);
    tmp = tmp->next;
    len--;
  }
}

/*
  p-ийн зааж буй List-с x тоог хайн олдсон хаягийг буцаана.
  Олдохгүй бол NULL хаяг буцаана.
 */
Elm *l_search(List *p, int x)
{
  int i;
  Elm *el = p->head;
  for (i = 0; i < p->len; i++)
  {
    if (el->x == x)
    {
      return el;
    }
    el = el->next;
  }
  return NULL;
}
