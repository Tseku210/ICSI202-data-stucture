#include "DS.h"
/*
  p-ийн зааж буй Stack-т x утгыг оруулна
 */
void s_push(Stack *p, int x)
{
        Elm *newEl = malloc(sizeof(struct Elm));
        newEl->x = x;
        if (p->top == NULL)
        {
                p->top = newEl;
                newEl->next = NULL;
                p->len++;
                return;
        }
        newEl->next = p->top;
        p->top = newEl;
        p->len++;
}
/*
  p-ийн зааж буй Stack-аас гарах функц
 */
void s_pop(Stack *p)
{
        if (p->len == 0)
                return;
        Elm *tmp = p->top;
        p->top = p->top->next;
        free(tmp);
        p->len--;
}
/*
    p-ийн зааж буй Stack-д байгаа элементүүдийг хэвлэх функц.
    Хамгийн сүүлд орсон элементээс эхлэн дарааллаар, нэг мөрөнд
    нэг л элемент хэвлэнэ.
 */
// try recursives
void s_print(Stack *p) // memcpy for mergesort
{
        Elm *el = p->top;
        int len = p->len;
        while (len > 0)
        {
                printf("%d\n", el->x);
                el = el->next;
                len--;
        }
}
