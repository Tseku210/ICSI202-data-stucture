#include "DS.h"

/* p-ийн зааж буй Queue-д x утгыг хийнэ */
void q_push(Queue *p, int x)
{
        Elm *el = malloc(sizeof(struct Elm));
        el->x = x;
        el->next = NULL;
        if (p->len == 0)
        {
                p->head = el;
                p->tail = el;
                p->len++;
                return;
        }
        p->tail->next = el;
        p->tail = el;
        p->len++;
}

/* p-ийн зааж буй Queue-с гаргана */
void q_pop(Queue *p)
{
        if (p->len == 0)
                return;
        Elm *tmp = p->head;
        p->head = p->head->next;
        free(tmp);
        p->len--;
}

/*
  p-ийн зааж буй Queue-н утгуудыг хэвлэнэ.
  Хамгийн эхний элементээс эхлэн дарааллаар, нэг мөрөнд
  нэг л элемент хэвлэнэ.
 */
void q_print(Queue *p)
{
        int len = p->len;
        Elm *tmp = p->head;
        while (len > 0)
        {
                printf("%d\n", tmp->x);
                tmp = tmp->next;
                len--;
        }
}
