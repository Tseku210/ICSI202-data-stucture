#include "DS.h"

// grid буюу N*N хэмжээтэй талбар
// N <= 5000 учраас хэмжээг 5000-аар авна
int grid[5000][5000];

void uf_free(WeightedUF *p_uf)
{
	free(p_uf->id);
	free(p_uf->sz);
	return;
}

void uf_print(int n, int p, int k)
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (i == p && j == k)
			{
				printf("*");
			}
			else
			{
				grid[i][j] ? printf("o") : printf("x");
			}
		}
		printf("\n");
	}
	printf("\n");
}

int main()
{
	int n, m, l;
	scanf("%d%d", &n, &m);

	WeightedUF uf;
	uf_init(&uf, n * n + 2); // Нэмэлт 2 хийсвэр оройг нэмнэ.
	// Цаашаа үргэлжүүлэн бичнэ үү!
	// ...
	int i, j, p, count = 0, found = 0;
	int virtual_top = n * n, virtual_bottom = n * n + 1;

	// grid-г эхэлж битүү (0) болгох шаардлагагүй учир нь C хэл дээр хүснэгт үүсгэхэд 0-ээр дүүргэгддэг.

	for (l = 0; l < m; l++)
	{
		scanf("%d%d", &j, &p);
		grid[j][p] = 1;
		if (!found)
		{
			count++;
			if (grid[j][p])
			{
				// virtual top тай холбогдсон эсэх
				if (j == 0)
					uf_union(&uf, n * n, j * n + p);

				// virtaul bottom той холбогдсон эсэх
				if (j == n - 1)
					uf_union(&uf, n * n + 1, j * n + p);

				// бусад 4-н орой онгорхой эсэх
				if (j > 0 && grid[j - 1][p])
					uf_union(&uf, j * n + p, (j - 1) * n + p);
				if (j < n - 1 && grid[j + 1][p])
					uf_union(&uf, j * n + p, (j + 1) * n + p);
				if (j > 0 && grid[j][p - 1])
					uf_union(&uf, j * n + p, j * n + (p - 1));
				if (j < n - 1 && grid[j][p + 1])
					uf_union(&uf, j * n + p, j * n + (p + 1));

				// Нэвчилт болсон эсэхийг шалгана
				if (uf_find(&uf, n * n) == uf_find(&uf, n * n + 1))
				{
					found = 1;
				}
			}
		}
	}
	// Олдсон бол count, олдоогүй учир -1 хэвлэнэ
	if (found == 1)
		printf("%d\n", count);
	else
		printf("-1\n");

	uf_free(&uf);
	return 0;
}
