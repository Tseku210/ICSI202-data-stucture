#include "DS.h"

void uf_init(WeightedUF *p_uf, int n)
{
	p_uf->N = n;
	p_uf->id = (int *)malloc(sizeof(int) * n);
	p_uf->sz = (int *)malloc(sizeof(int) * n);
	int i;
	for (i = 0; i < n; i++)
	{
		p_uf->id[i] = i;
		p_uf->sz[i] = 1;
	}
}

int uf_connected(WeightedUF *p_uf, int p, int q)
{
	// хоёр орой нэг үндэс оройтой эсэхийг шалгана.
	return uf_find(p_uf, p) == uf_find(p_uf, q);
}

int uf_find(WeightedUF *p_uf, int p)
{
	// Үндэс оройг олтол recursive-аар ажиллана
	if (p_uf->id[p] != p)
		p_uf->id[p] = uf_find(p_uf, p_uf->id[p]);

	return p_uf->id[p];
}

void uf_union(WeightedUF *p_uf, int p, int q)
{
	int root_p = uf_find(p_uf, p);
	int root_q = uf_find(p_uf, q);
	if (p_uf->sz[root_p] < p_uf->sz[root_q])
	{
		p_uf->id[root_p] = root_q;
		p_uf->sz[root_q] += p_uf->sz[root_p];
	}
	else
	{
		p_uf->id[root_q] = root_p;
		p_uf->sz[root_p] += p_uf->sz[root_q];
	}
}
