#include "DS.h"

/*
  `ptree`-ийн зааж байгаа модонд `x` утгыг оруулна.
  Оруулахдаа хоёртын хайлтын модны зарчмаар оруулах бөгөөд оруулсан
  байрлалаас дээшхи өвөг эцгийн `len`, `height` утгууд өөрчлөгдөнө.
  Мод хоосон байсан бол `ptree->root` хаяг өөрчлөгдөж шинээр орсон оройг заана.
 */

Elm *createNode(int x)
{
        Elm *el = malloc(sizeof(Elm));
        el->x = x;
        el->height = el->len = 1;
        el->L = el->R = NULL;
        return el;
}

void insert(Elm **root, int x)
{
        if (*root == NULL)
        {
                *root = createNode(x);
                return;
        }
        if (x < (*root)->x)
                insert(&(*root)->L, x);
        else
                insert(&(*root)->R, x);

        if (!(*root)->L && !(*root)->R)
                (*root)->height += 1;
        else if (((*root)->L && !(*root)->R) || (!(*root)->L && (*root)->R))
                (*root)->height = (*root)->L ? (*root)->L->height + 1 : (*root)->R->height + 1;
        else
                (*root)->height =
                    (*root)->L->height > (*root)->R->height ? (*root)->L->height + 1 : (*root)->R->height + 1;

        (*root)->len++;
}

void bs_put(BST *ptree, int x)
{
        insert(&ptree->root, x);
}

/*
  `ptree`-ийн зааж байгаа модноос `x` утгыг хайн олдсон оройн `Elm*` хаягийг буцаана.
  Олдохгүй бол `NULL` хаягийг буцаана.
  Мод дандаа ялгаатай элементүүд хадгална гэж үзэж болно.
 */
Elm *search(Elm *root, int x)
{
        if (root == NULL)
                return root;

        if (root->x > x)
                search(root->L, x);
        else if (root->x < x)
                search(root->R, x);
        else
                return root;
}

Elm *bs_get(const BST *ptree, int x)
{
        return search(ptree->root, x);
}

/*
  Устгах функц: ХХМноос `x` утгыг хайж олоод устгана.
  Олдохгүй бол юу ч хийхгүй.
 */
Elm *rightMin(Elm *root)
{
        Elm *el = root;
        while (el && el->L)
        {
                el = el->L;
        }
        return el;
}

void delete(Elm **root, int x)
{
        if (*root == NULL)
                return;

        if ((*root)->x > x)
                delete (&(*root)->L, x);
        else if ((*root)->x < x)
                delete (&(*root)->R, x);
        else
        {
                Elm *tmp;
                if ((*root)->L == NULL && (*root)->R == NULL)
                { // Навч байвал
                        free(*root);
                        *root = NULL;
                        return;
                }
                else if ((*root)->R == NULL)
                { // Ганц хүү байвал
                        tmp = (*root)->L;
                        free(*root);
                        *root = tmp;
                        return;
                }
                else if ((*root)->L == NULL)
                { // Ганц хүү байвал
                        tmp = (*root)->R;
                        free(*root);
                        *root = tmp;
                        return;
                }
                else
                { // Хоёр хүү байвал
                        tmp = rightMin((*root)->R);
                        (*root)->x = tmp->x;
                        delete (&(*root)->R, (*root)->x);
                }
        }

        int left_height = (*root)->L ? (*root)->L->height : 0;
        int right_height = (*root)->R ? (*root)->R->height : 0;
        (*root)->height = (left_height > right_height ? left_height : right_height) + 1;

        (*root)->len--;
}

void bs_del(BST *ptree, int x)
{
        delete (&ptree->root, x);
}

/*
  Хамгийн багыг устгах функц: ХХМноос хамгийг бага утгыг нь устгах функц.
  Устгасан утгыг буцаана.
 */
Elm *delete_minimum(Elm *r)
{
        if (!r->L)
        {
                Elm *tmp = r->R;
                free(r);
                return tmp;
        }
        r->L = delete_minimum(r->L);
        r->len--;
        return r;
}

int bs_delMin(BST *ptree)
{
        if (ptree->root == NULL)
                return -1; // tree is empty

        int minVal;
        Elm *lastNode = ptree->root;
        while (lastNode->L)
                lastNode = lastNode->L;

        minVal = lastNode->x;
        ptree->root = delete_minimum(ptree->root);
        return minVal;
}

/*
  ХХМыг inorder дарааллаар, нэг мөрөнд нэг утга хэвлэнэ.
 */
void inorder(Elm *root)
{
        if (root == NULL)
                return;

        inorder(root->L);
        printf("%d %d %d\n", root->x, root->len, root->height);
        inorder(root->R);
}

void bs_inorder(const BST *ptree)
{
        inorder(ptree->root);
}

/*
  ХХМноос `x` утгаас эрс бага буюу тэнцүү байх хэдэн орой байгааг олж буцаана.
  Өөрөөр хэлбэл хоёртын хайлтын модны утгуудыг өсөх дарааллаар байрлуулбал
  `x`-ийг оролцуулаад өмнө хэдэн тоо байх вэ? гэсэн үг.
  `x` утга заавал модонд байх албагүй.
 */
int rank(Elm *root, int x)
{
        if (root == NULL)
                return 0;

        if (x == root->x)
                return (root->L ? root->L->len : 0) + 1;
        else if (x < root->x)
                return rank(root->L, x);
        else
                return (root->L ? root->L->len : 0) + 1 + rank(root->R, x);
}

int bs_rank(const BST *ptree, int x)
{
        return rank(ptree->root, x);
}

/*
  ХХМноос `x` утгатай оройг хайж олоод, тухайн оройд суурилсан
  дэд модонд хэдэн орой байгааг олж буцаана.
  Олдохгүй бол -1-ийг буцаана.
 */
int bs_size(const BST *ptree, int x)
{
        Elm *node = bs_get(ptree, x);

        if (!node)
                return -1;

        return node->len;
}

/*
  XXMноос `x`-ээс бага буюу тэнцүү байх хамгийн их утгын `Elm *` хаягийг олж буцаана.
  Олдохгүй бол `NULL` хаягийг буцаана.
 */

Elm *bs_floor(const BST *ptree, int x)
{
        if (ptree->root == NULL)
                return NULL;

        Elm *current = ptree->root;
        Elm *best = NULL;
        while (current != NULL)
        {
                if (current->x == x)
                        return current;
                else if (current->x > x)
                        current = current->L;
                else
                {
                        best = current;
                        current = current->R;
                }
        }
        return best;
}

/*
  XXMноос `x`-ээс их буюу тэнцүү байх хамгийн бага утгын `Elm *` хаягийг олж буцаана.
  Олдохгүй бол `NULL` хаягийг буцаана.
 */

Elm *bs_ceiling(const BST *ptree, int x)
{
        if (ptree->root == NULL)
                return NULL;

        Elm *current = ptree->root;
        Elm *best = NULL;
        while (current != NULL)
        {
                if (current->x == x)
                        return current;
                else if (current->x < x)
                        current = current->R;
                else
                {
                        best = current;
                        current = current->L;
                }
        }
        return best;
}

/*
  ХХМноос `x` утгатай оройг хайж олоод, тухайн оройд суурилсан
  дэд модны өндөр хэд байгааг олж буцаана. Олдохгүй бол -1-ийг буцаана.
 */
int bs_height(const BST *ptree, int x)
{
        Elm *node = bs_get(ptree, x);
        if (!node)
                return -1;
        return node->height;
}