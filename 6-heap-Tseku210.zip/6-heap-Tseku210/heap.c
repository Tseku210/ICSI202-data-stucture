#include "DS.h"
#include <stdio.h>

static void swim(Heap *p, int);
static void sink(Heap *p, int);

/*
  Хоёр зурвасын чухлыг харьцуулах функц.
  b нь илүү чухал бол 1, бусад үед 0-ыг буцаах функц.
  Өөрөөр хэлбэл a < b үйлдэл юм.
*/
int less(const Msg *a, const Msg *b)
{
        if (a->priority > b->priority)
        {
                // printf("\nbiylsen %d %d-ees ih", b->priority, a->priority);
                return 1;
        }
        else if (a->priority == b->priority)
        {
                if (a->time > b->time)
                {
                        return 1;
                }
                return 0;
        }
        return 0;
}

/*
  Оруулах функц. heap зарчмаар чухлын дарааллыг баримтлан оруулна.
  Ингэхдээ хамгийн чухал зурвас heap-ын оройд хадгалагдана.
  x зурвасыг p-ын зааж буй heap бүтцэд оруулна.
 */
void insert(Heap *p, const Msg x)
{
        // printf("\nn: %d\n", p->h_len);
        p->h_arr[p->h_len++] = x;
        // printf("\n%s %d\n", p->h_arr[p->h_len - 1].text, p->h_arr[p->h_len - 1].priority);
        // printf("\nbefore high: %d\n", p->h_arr[0].priority);
        swim(p, p->h_len - 1);
}

void swap(Msg *a, Msg *b)
{
        Msg tmp = *a;
        *a = *b;
        *b = tmp;
}

/*
  Heap бүтцийн swim үйлдэл.
  k нь swim үйлдлийг p-ын зааж буй heap дээр эхлүүлэх индекс.
 */
static void swim(Heap *p, int k)
{
        int parentI = (k - 1) / 2;
        while (k > 0 && less(&p->h_arr[parentI], &p->h_arr[k]))
        {
                // printf("\n%d %d\n", p->h_arr[parentI].priority, p->h_arr[k].priority);
                // printf("\nparent: %d\n", p->h_arr[parentI].priority);
                swap(&p->h_arr[k], &p->h_arr[parentI]);
                // printf("\n%d %d\n", p->h_arr[parentI].priority, p->h_arr[k].priority);
                // printf("\npAfter: %d\n", p->h_arr[parentI].priority);
                k = parentI;
                parentI = (k - 1) / 2;
        }
        // printf("\nhigh: %d\n", p->h_arr[0].priority);
}

/*
  Heap бүтцийн sink үйлдэл.
  k нь sink үйлдлийг p-ын зааж буй heap дээр эхлүүлэх индекс.
 */
static void sink(Heap *p, int k)
{
        int childI = (2 * k) + 1;
        while (childI < p->h_len)
        {
                if (childI + 1 < p->h_len && less(&p->h_arr[childI], &p->h_arr[childI + 1]))
                        childI++;
                if (!less(&p->h_arr[k], &p->h_arr[childI]))
                        break;
                swap(&p->h_arr[k], &p->h_arr[childI]);
                k = childI;
                childI = 2 * k + 1;
        }
        // int max = k;
        // int lc = (2 * k) + 1;
        // if (lc <= p->h_len && less(&p->h_arr[max], &p->h_arr[lc]))
        // {
        //         max = lc;
        // }
        // int rc = (2 * k) + 2;
        // if (rc <= p->h_len && less(&p->h_arr[max], &p->h_arr[rc]))
        // {
        //         max = rc;
        // }
        // if (k != max)
        // {
        //         swap(&p->h_arr[k], &p->h_arr[max]);
        //         sink(p, max);
        // }
}

/*
  p-ын зааж буй heap бүтцээс оройн элементийг гаргаад буцаах функц.
  Гаргасны дараа орой бүрийн хувьд heap зарчим хадгалах ёстой.
 */
Msg delMin(Heap *p)
{
        Msg delEl = p->h_arr[0];
        // printf("swapping: %s, %s", p->h_arr[0].text, p->h_arr[p->h_len - 1].text);
        swap(&p->h_arr[0], &p->h_arr[p->h_len - 1]);
        // printf("\nafter swapping: %s, %s\n", p->h_arr[0].text, p->h_arr[p->h_len - 1].text);
        p->h_len--;
        sink(p, 0);
        return delEl;
}