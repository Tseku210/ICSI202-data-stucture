#include "myinclude.h"

void read(int A[], int n)
{
    int i;
    for (i = 0; i < n; i++)
        scanf("%d", &A[i]);
}

void print(int A[], int n)
{
    int i;
    for (i = 0; i < n; i++)
        printf("%d ", A[i]);
    printf("\n");
}

int max(int A[], int n)
{
    int i, max = A[0];
    for (i = 1; i < n; i++)
    {
        if (A[i] > max)
        {
            max = A[i];
        }
    }
    return max;
}

int min(int A[], int n)
{
    int i, min = A[0];
    for (i = 1; i < n; i++)
    {
        if (A[i] < min)
        {
            min = A[i];
        }
    }
    return min;
}

void copy(int A[], int n, int B[])
{
    int i;
    for (i = 0; i < n; i++)
    {
        B[i] = A[i];
    }
}

int find(int A[], int n, int x)
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (A[i] == x)
        {
            return i;
        }
    }
    return -1;
}

int make_set(int A[], int n, int B[])
{
    int i, j, rep = 0, c = 0; // i=2
    for (i = 0; i < n; i++)   // 1, 5, 1*, 2, 3
    {
        for (j = 0; j < c; j++) // 0 1
        {
            if (A[i] == B[j]) //
            {
                rep = 1;
            }
        }
        if (rep == 0)
        {
            B[c] = A[i]; // B[0]=1 B[1]=5
            c++;         // 1 2
        }
        rep = 0;
    }
    return c;
}

int union_set(int A[], int n, int B[], int m)
{
    int i, j, rep = 0, c = 0;
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n + c; j++)
        {
            if (B[i] == A[j])
            {
                rep = 1;
            }
        }
        if (rep == 0)
        {
            A[n + c] = B[i];
            c++;
        }
        rep = 0;
    }
    return n + c;
}

int intersection_set(int A[], int n, int B[], int m, int C[])
{
    int i, j, c_len = 0;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            if (A[i] == B[j])
            {
                C[c_len] = A[i];
                c_len++;
            }
        }
    }
    return c_len;
}
