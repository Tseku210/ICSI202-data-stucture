#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define Q 997
#define R 256

int case_insensitive = 0;

/*
  s тэмдэгтэн цувааны hash-ыг буцаана
 */
int hash(const char *s)
{
        int hash = 0, i = 0;
        while (s[i] != '\0')
        {
                if (case_insensitive)
                        // hash = toLower(s[i]) * (31 * hash);
                        hash = (hash * R + tolower(s[i])) % Q;
                else
                        // hash = s[i] * (31 * hash);
                        hash = (hash * R + s[i]) % Q;
                i++;
        }
        // return abs(hash & 0x7fffffff) % Q;
        return hash;
}

/*
  Функц нь buf доторх тэмдэгтэн цуваанаас index байрлалаас эхлэн
  pattern тэмдэгтийг хайна. Олдвол олдсон индексийг буцанаа.
  Олдохгүй бол -1 утгыг буцаана.
  case_insensitive = 1 бол том жижиг гэж ялгалгүйгээр тааруулна.
  Мөн мөрний мэдээллийг давхар хариуцаж явна.
  Мөр шилжих үед (*pline)++

  buf     :    Хайлт хийх тэмдэгтэн цуваа
  n       :    buf-ын урт
  index   :    Хайлтыг эхлэх индекс
  pattern :    Хайх үг
  m       :    pattern-ны урт
  pat_hash:    pattern хэвийн hash
  pline   :    Мөрийн мэдээлэл хадгалах хувьсагчийн хаяг
 */
int find(const char *buf, int n, int index, const char *pattern, int m, int pat_hash, int *pline)
{
        int i;
        int bufHash = 0;
        // *Шинэ rm тооцоолох шаардлага гарсан
        int h = 1;

        for (i = index; i < index + m; i++)
        {
                if (case_insensitive)
                        bufHash = (tolower(buf[i]) + (bufHash * R)) % Q;
                else
                        bufHash = ((buf[i]) + (bufHash * R)) % Q;
        }

        // Үлдсэн үсгүүдийн хашийг тооцоолох
        int j;
        for (i = index; i <= n - m; i++)
        {
                for (j = 0; j < m; j++)
                {
                        if (case_insensitive)
                        {
                                if (tolower(buf[i + j]) != tolower(pattern[j]))
                                        break;
                        }
                        else
                        {
                                if (buf[i + j] != pattern[j])
                                        break;
                        }
                }
                if (j == m)
                        return i;

                if (i < n - m)
                {
                        if (case_insensitive)
                                bufHash = (R * (bufHash - tolower(buf[i]) * h) + tolower(buf[i + m])) % Q;
                        else
                                bufHash = (R * (bufHash - buf[i] * h) + buf[i + m]) % Q;
                        if (bufHash < 0)
                                bufHash = bufHash + Q;
                }
                if (buf[i] == '\n')
                {
                        (*pline)++;
                }
        }
        return -1;
}
int main(int argc, char *argv[])
{
        // Аргументийн тоо ядаж 3 байх ёстой.
        if (argc < 3)
        {
                printf("%s [-i] pattern FILE", argv[0]);
                exit(-1);
        }

        const char *pattern;
        if (argc > 3 && strcmp("-i", argv[1]) == 0)
        {
                case_insensitive = 1; // Том жижгийг хайхрахгүй адил гэж үзнэ.
                pattern = argv[2];
        }
        else
                pattern = argv[1];

        FILE *fin;
        fin = fopen(argv[argc - 1], "r");
        if (fin == NULL)
        {
                printf("Error openning %s file", argv[argc - 1]);
                exit(-1);
        }
        int len = 0;
        char ch;
        while (!feof(fin))
        {
                ch = fgetc(fin);
                len++; // Файлд доторх тэмдэгтүүдийг тоолъё.
        }
        char *buf;
        buf = (char *)malloc(sizeof(char) * (len + 1)); // Энд тэмдэгтүүдийг хадгална
        fseek(fin, 0, SEEK_SET);                        // Файл заагчийг буцаад эхлэлд нь аваачна.
        int i = 0;
        while (!feof(fin))
                buf[i++] = fgetc(fin); // Өгөгдлийг уншиж байна.
        buf[len - 1] = 0;              /* тэмдэгт мөр төгсгөл заагч */

        int ret = -1;
        int line = 0;
        int pat_hash = hash(pattern); // hash кодыг тооцоолно
        int m = strlen(pattern);
        do
        {
                ret = find(buf, len - 1, ret + 1, pattern, m, pat_hash, &line);
                if (ret != -1)
                {
                        printf("%d: ", line);
                        /*
                          Олдсон газраас доошоо 5
                          дээшээ 5 тэмдэгтийг хэвлэнэ.
                         */
                        int l = ret - 5;
                        int r = ret + strlen(pattern) + 5;
                        if (l < 0)
                                l = 0;
                        if (r >= len)
                                l = len - 1;
                        for (i = l; i <= r; i++)
                                printf("%c", buf[i]);
                        printf("\n");
                }
        } while (ret != -1);

        free(buf);
        return 0;
}
