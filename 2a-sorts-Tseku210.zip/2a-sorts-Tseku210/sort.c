#include "sort.h"
void read(int a[], int n)
{
	int i;
	for (i = 0; i < n; i++)
		scanf("%d", &a[i]);
}

void print(int a[], int n)
{
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", a[i]);
	printf("\n");
}

void insertion_sort(int a[], int n)
{
	/***************************************************
	 * Даалгавар: Энэ хэсэгт өөрийн insertion sort-ийг
	 * хийх кодыг бичнэ.
	 * a     нь эрэмбэлэх хүснэгт
	 * n     нь хүснэгтэд байгаа утгуудын тоо
	 ***************************************************/
	int i, j, tmp, el;
	for (i = 1; i < n; i++)				 // 3 1 1 7 2 ()
	{															 // 7
		el = a[i];									 // 1
		for (j = i - 1; j >= 0; j--) // 4
		{
			// printf("\na[j] = %d el = %d a[i] = %d\n", a[j], el, a[i]);
			if (a[j] > el) // true
			{
				tmp = a[j];			// 4
				a[j] = el;			// 1
				a[j + 1] = tmp; // 4
			}
			else
			{
				break;
			}
		}
	}
}
// !DAHIJ HARAH!
void selection_sort(int a[], int n)
{
	/***************************************************
	 * Даалгавар: Энэ хэсэгт өөрийн selection sort-ийг
	 * хийх кодыг бичнэ.
	 * a     нь эрэмбэлэх хүснэгт
	 * n     нь хүснэгтэд байгаа утгуудын тоо
	 ***************************************************/
	int i, j, tmp, swap_index, min;
	for (i = 0; i < n - 1; i++)		// 1 3 7 4 2
	{															// 0
		min = i;										// 1
		for (j = i + 1; j < n; j++) // 2
		{
			if (a[j] < a[min]) // 1
			{
				min = j; // 1
			}
		}
		tmp = a[i];		 // 4
		a[i] = a[min]; // 1
		a[min] = tmp;	 // 4
	}
}

void bubble_sort(int a[], int n)
{
	/***************************************************
	 * Даалгавар: Энэ хэсэгт өөрийн bubble sort-ийг
	 * хийх кодыг бичнэ.
	 * a     нь эрэмбэлэх хүснэгт
	 * n     нь хүснэгтэд байгаа утгуудын тоо
	 ***************************************************/
	int swapped = 0;
	int i, j, tmp;
	do
	{
		swapped = 0;
		for (i = 1; i < n; i++)
		{
			if (a[i - 1] > a[i])
			{
				tmp = a[i];
				a[i] = a[i - 1];
				a[i - 1] = tmp;
				swapped = 1;
			}
		}
	} while (swapped);
}
